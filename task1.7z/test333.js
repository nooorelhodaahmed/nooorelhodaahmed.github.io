
   

// Get the <span> element that closes the modal
//var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}



 $(window).on('load', function() { 
  $('#status').fadeOut(); 
  $('#preloader').delay(5000).fadeOut('slow'); 
     website.$('body').delay(2000).css({'overflow':'visible'});
    setTimeout(function(){ showSite() }, 2000);
     $(this).remove();
});

    

